
public class Main extends Employee
{
	float pf;
	
	
public Main(int emp_id, String name, float basic_sal,float pf) {
		super(emp_id,name,basic_sal);
		this.pf=pf;
		
		// TODO Auto-generated constructor stub
	}
	
public String toString()
{
	return  super.toString()+"/n pf will be"+pf;
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e1;
		e1=new Main(100,"parag",5000,40);
		e1.cal_sal();
		System.out.println(e1);

	}
	public void cal_sal()
	{
			System.out.println(basic_sal+pf);
	}
}
