
abstract class Employee {
	int emp_id;
	String name;
	float basic_sal=5000;

abstract void cal_sal();     //abstract method

public Employee(int emp_id,String name,float basic_sal)
{
	this.emp_id=emp_id;
	this.name=name;
	this.basic_sal=basic_sal;
}	

public String toString()
{
	return "Emplyee id is " + emp_id + "Employee name is " + name + "salary having " + basic_sal;
}

}