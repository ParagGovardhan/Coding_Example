
public class Emp {
	int emp_id;
	String name;
	float basic;
	int hra;

	Emp() {
		System.out.println("Default Constructor of base class");
		emp_id = 2;
		name = "xyz";
		basic = 30000.0f;
		hra = 5;
	}

	Emp(int emp_id, String name, float basic, int da) {
		System.out.println("Paramaterized constructor of base class");
		this.emp_id = emp_id;
		this.name = name;
		this.basic = basic;
		this.hra = hra;

	}

	public void cal_Sal() // base class method
	{
		System.out.println("cal_salary will be=" + basic);
	}

	public String toString() {
		return "Employee id=" + emp_id + "Name of emp==" + name + "basic salary==" + basic + "hra==" + hra;
	}

	public void cal_sal() // method overloading
	{
		System.out.println("cal_salary will be==" + hra);
	}

}
