
public class Main {
	public static void main(String[] args) {
		Emp e1 = new Emp();
		e1.cal_Sal();

		Emp e2 = new Emp(3, "Abc", 100000.0f, 0);
		e2.cal_Sal();

		Manager m1 = new Manager();
		System.out.println(m1);
		m1.cal_Sal();

		Manager m2 = new Manager(1, "Demo1", 30000.05f, 10, 5000.36f, 3);
		System.out.println(m2);
		m2.cal_Sal();

	}
}
