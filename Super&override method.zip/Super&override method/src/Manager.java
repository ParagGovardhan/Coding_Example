
public class Manager extends Emp {
	float incentive;
	int no_experience;

	Manager() {
		super(); //
		incentive = 70000.0f;
		no_experience = 8;
		System.out.println("Default Constructor of derived class ");
	}

	Manager(int emp_id, String name, float basic, int hra, float incentive, int no_experience) {
		super(emp_id, name, basic, hra);
		System.out.println("Paramaterized Constructor of derived class ");
		this.incentive = incentive;
		this.no_experience = no_experience;
	}

	public String toString() {
		return super.toString() + "incentive will be=" + incentive + "Experience for this=" + no_experience;
	}

	public void cal_Sal() // method Override by derived class
	{

		System.out.println("cal_salary will be=" + (basic + incentive));
	}

}
